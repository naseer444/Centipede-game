/*
 * Bomb.cpp
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#include "Bomb.h"

Bomb::Bomb()  {
}
void Bomb::move(){
	this->getPosition().setYaxis(this->getPosition().getYaxis()+10);
}
void Bomb::positionOfBullet(int x,int y){
	this->getPosition().setXaxis(x+10);;
	this->getPosition().setYaxis(y);
}
int Bomb::getXB(){
	return getPosition().getXaxis();
}
int Bomb::getYB(){
			return this->getPosition().getYaxis();
}
void Bomb::draw(){
	 DrawCircle(this->getPosition().getXaxis(),this->getPosition().getYaxis(),5,colors[75]);

}

Bomb::~Bomb() {
	// TODO Auto-generated destructor stub
}

