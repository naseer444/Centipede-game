/*
 * MagicSeg.cpp
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#include "MagicSeg.h"

MagicSeg::MagicSeg() {
	// TODO Auto-generated constructor stub

}
void MagicSeg::draw(){

	 DrawCircle(this->getPosition().getXaxis(),this->getPosition().getYaxis(),10,colors[PURPLE]);
}

void MagicSeg::move(){

}
int MagicSeg::getX(){
	return this->getPosition().getXaxis();
}
   int MagicSeg::getY(){
	   return this->getPosition().getYaxis();
   }
   void MagicSeg::setX(int x){
	   this->getPosition().setXaxis(x);
   }
   void MagicSeg::setY(int y){
	   this->getPosition().setYaxis(y);
   }
MagicSeg::~MagicSeg() {
	// TODO Auto-generated destructor stub
}

