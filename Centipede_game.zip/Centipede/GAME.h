/*
 * GAME.h
 *
 *  Created on: May 3, 2019
 *      Author: naseer
 */

#ifndef GAME_H_
#define GAME_H_
#include<cmath>
#include<sstream>
using namespace std;
using namespace std;
#include "Player.h"
#include "Position.h"
#include "ScoreBoard.h"
#include "Mushroom.h"
#include "MoveableObject.h"
#include "Bomb.h"
#include "Centipede.h"
class GAME {
	Bomb b;
	Centipede centi;
	Player ply;
	Position pos;
	ScoreBoard board;
	Mushroom *mush;
	int score;

public:
	GAME();
	virtual ~GAME();
	 Player& getPly()  ;
	 void drawForMushroom();
	void setPly(const Player& ply) ;
	const Position& getPos() const ;
	void setPos(const Position& pos) ;
	const GameObject& getObj() const ;
	void setObj(const GameObject& obj) ;
	 ScoreBoard& getBoard()  ;
	void setBoard(const ScoreBoard& board) ;
	 Centipede& getCenti() ;
	void setCenti( Centipede& centi) ;
	 Mushroom* getMush() ;
	 Bomb& getB() ;
	void setB( Bomb& b) ;
	void checkCollision();
    void CentipedeDraw();
	int getScore() ;
	void setScore(int score) ;
	void drawForScore();
};

#endif /* GAME_H_ */
