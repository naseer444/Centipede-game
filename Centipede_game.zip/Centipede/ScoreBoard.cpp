/*
 * ScoreBoard.cpp
 *
 *  Created on: Apr 30, 2019
 *      Author: naseer
 */

#include "ScoreBoard.h"

ScoreBoard::ScoreBoard():NumberOfLives(3),score(0) {
	// TODO Auto-generated constructor stub

}/*
ScoreBoard::ScoreBoard(int nl,int s){

	}
	*/
int ScoreBoard::getNumberOfLives() const {
		return NumberOfLives;
	}

	void ScoreBoard::setNumberOfLives(int numberOfLives) {
		NumberOfLives = numberOfLives;
	}

	int ScoreBoard::getScore() const {
		return score;
	}

	void ScoreBoard::setScore(int score) {
		this->score = score;
	}
	 void ScoreBoard::drawReal(int score){
		 stringstream temp1;
		 temp1<<score;
		 string forTemp1=temp1.str();
		 DrawString( 130, 800, forTemp1, colors[WHITE]);

	 }
	 void ScoreBoard::draw(){
		 stringstream temp1,temp2;
		 temp1<<score;
		 temp2 << NumberOfLives;
		 string forTemp1=temp1.str();
		 string forTemp2=temp2.str();
		//  DrawString( 130, 800, forTemp1, colors[GREEN]);
		 DrawString( 50, 800, "Score=", colors[MISTY_ROSE]);
		  DrawString( 820, 800, "Number of lives=", colors[MISTY_ROSE]);
		  DrawString( 1000, 800,forTemp2, colors[RED]);
	 }


ScoreBoard::~ScoreBoard() {
	// TODO Auto-generated destructor stub
}

