/*
 * Centipede.h
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#ifndef CENTIPEDE_H_
#define CENTIPEDE_H_
#include "Segment.h"
#include "LazySeg.h"
#include "MagicSeg.h"
class Centipede {
	MagicSeg m;
	LazySeg *lazyC;
	bool temp;
public:
	Centipede();
	void draw();
	void initailize();
	void move();
	void drawHead();
	void movement();
	virtual ~Centipede();
	 LazySeg*& getLazyC() ;
	void setLazyC( LazySeg*& lazyC) ;
	bool isTemp();
	void setTemp(bool temp) ;
	 MagicSeg& getM() ;
	void setM( MagicSeg& m) ;
};

#endif /* CENTIPEDE_H_ */
