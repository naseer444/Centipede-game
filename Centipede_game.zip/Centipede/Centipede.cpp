/*
 * Centipede.cpp
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#include "Centipede.h"
#include "util.h"
#include "Position.h"
Centipede::Centipede() {
	temp=0;
	lazyC=new LazySeg[9];
}
void Centipede::initailize(){
	m.getPosition().setXaxis(550);
	m.getPosition().setYaxis(800);
	for(int i=0; i<10; i++){
		lazyC[i].getPosition().setXaxis(m.getPosition().getXaxis() );
		lazyC[i].getPosition().setYaxis(m.getPosition().getYaxis());
	}

}
void Centipede::drawHead(){
	DrawCircle(m.getPosition().getXaxis(),m.getPosition().getYaxis(),10,colors[10]);
}
void Centipede::draw(){

	for(int i=0; i<9; i++)
	{

	  DrawCircle( lazyC[i].getPosition().getXaxis() , lazyC[i].getPosition().getYaxis() ,10,colors[PURPLE])  ;
	}


	}
void Centipede::move(){

}

 LazySeg*& Centipede::getLazyC()  {
	return lazyC;
}

void Centipede::setLazyC( LazySeg*& lazyC) {
	this->lazyC = lazyC;
}
bool Centipede::isTemp()  {
		return temp;
	}

	void Centipede::setTemp(bool temp) {
		this->temp = temp;
	}
	 MagicSeg& Centipede::getM() {
			return m;
		}

		void Centipede::setM( MagicSeg& m) {
			this->m = m;
		}
Centipede::~Centipede() {
	// TODO Auto-generated destructor stub
}

