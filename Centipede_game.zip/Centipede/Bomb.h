/*
 * Bomb.h
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#ifndef BOMB_H_
#define BOMB_H_
#include "MoveableObject.h"
#include "Player.h"

#include"util.h"
class Bomb :public MoveableObject{
public:
	Bomb();
	void positionOfBullet(int x,int y);
	int getPositionx();
	int getPositiony();
	int getXB();
	int getYB();
	void move();
	void draw();
	virtual ~Bomb();
};

#endif /* BOMB_H_ */
