/*
 * MagicSeg.h
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#ifndef MAGICSEG_H_
#define MAGICSEG_H_
#include "util.h"
#include "Position.h"
#include "MoveableObject.h"
using namespace std;
#include<iostream>
class MagicSeg:public MoveableObject {

public:
	MagicSeg();
	void draw();
	void move();

	virtual ~MagicSeg();
    int getX();
    int getY();
    void setX(int x);
    void setY(int y);
};

#endif /* MAGICSEG_H_ */
