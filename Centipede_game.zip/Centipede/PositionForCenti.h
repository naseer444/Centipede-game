/*
 * PositionForCenti.h
 *
 *  Created on: May 7, 2019
 *      Author: naseer
 */

#ifndef POSITIONFORCENTI_H_
#define POSITIONFORCENTI_H_

class PositionForCenti {
	int x;
	int y;
public:
	PositionForCenti();
	virtual ~PositionForCenti();

	int getX() ;
	void setX(int x);
	int getY() ;
	void setY(int y) ;
};

#endif /* POSITIONFORCENTI_H_ */
