/*
 * PositionForCenti.cpp
 *
 *  Created on: May 7, 2019
 *      Author: naseer
 */

#include "PositionForCenti.h"

PositionForCenti::PositionForCenti() {
	// TODO Auto-generated constructor stub

}
int PositionForCenti::getX()  {
		return x;
	}

	void PositionForCenti::setX(int x) {
		this->x = x;
	}

	int PositionForCenti::getY() {
		return y;
	}

	void PositionForCenti::setY(int y) {
		this->y = y;
	}
PositionForCenti::~PositionForCenti() {
	// TODO Auto-generated destructor stub
}

