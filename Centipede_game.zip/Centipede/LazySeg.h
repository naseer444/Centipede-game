/*
 * LazySeg.h
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#ifndef LAZYSEG_H_
#define LAZYSEG_H_
#include "util.h"
#include "PositionForCenti.h"
#include"Segment.h"
#include "MoveableObject.h"
class LazySeg:public MoveableObject {

public:
	LazySeg();
   void draw();
   void move();
   int getX();
      int getY();
      void setX(int x);
      void setY(int y);
   virtual ~LazySeg();

};

#endif /* LAZYSEG_H_ */
