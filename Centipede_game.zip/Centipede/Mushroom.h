/*
 * Mushroom.h
 *
 *  Created on: Apr 30, 2019
 *      Author: naseer
 */

#ifndef MUSHROOM_H_
#define MUSHROOM_H_
#include "GameObject.h"
#include "util.h"
#include "Position.h"
#include <cstdlib>
#include <time.h>
class Mushroom :public GameObject{
	Position *arr;
public:
	Mushroom();
	void draw();
	virtual ~Mushroom();
	 Position*& getArr()  ;

	void setArr(const Position*& arr);
};

#endif /* MUSHROOM_H_ */
