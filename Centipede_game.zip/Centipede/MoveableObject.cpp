/*
 * MoveableObject.cpp
 *
 *  Created on: May 1, 2019
 *      Author: naseer
 */

#include "MoveableObject.h"

MoveableObject::MoveableObject() {
	// TODO Auto-generated constructor stub

}
void MoveableObject::move(){

}
void MoveableObject::draw(){

}
MoveableObject::~MoveableObject() {
	// TODO Auto-generated destructor stub
}

