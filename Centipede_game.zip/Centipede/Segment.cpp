/*
 * Segment.cpp
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#include "Segment.h"

Segment::Segment() {
	// TODO Auto-generated constructor stub

}
void Segment::move (){

}
void Segment::draw(){

}

Segment::~Segment() {
	// TODO Auto-generated destructor stub
}

