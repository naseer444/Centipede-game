/*
 * GAME.cpp
 *
 *  Created on: May 3, 2019
 *      Author: naseer
 */

#include "GAME.h"
GAME::GAME() {
	mush=new Mushroom[30];
		srand(time(0));
		for(int i=0; i<30; i++){
mush[i].getArr()->setXaxis(rand()%900);
mush[i].getArr()->setYaxis(rand()%(641)+200);
score=0;
}
}
 Player& GAME::getPly()  {
		return ply;
	}

	void GAME::setPly(const Player& ply) {
		this->ply = ply;
	}

	const Position& GAME::getPos() const {
		return pos;
	}

	void GAME::setPos(const Position& pos) {
		this->pos = pos;
	}
	 ScoreBoard& GAME::getBoard()  {
			return board;
		}

		void GAME::setBoard(const ScoreBoard& board) {
			this->board = board;
		}
		 Mushroom* GAME::getMush()  {
				return mush;
			}
	 Bomb& GAME::getB()  {
		 		return b;
		 	}

		 	void GAME::setB( Bomb& b) {
		 		this->b = b;
		 	}
	    Centipede& GAME::getCenti()  {
	   		return centi;
	   	}

	   	void GAME::setCenti( Centipede& centi) {
	   		this->centi = centi;
	   	}
	    void GAME::drawForMushroom(){
	    	for(int i=0; i<30; i++)
	    		 DrawSquare( mush[i].getArr()->getXaxis() ,mush[i].getArr()->getYaxis()  ,15,colors[GREEN]);
	    }
	   	void GAME::checkCollision(){
	   		int tempx,tempy;
	   		int tx,ty; int flag;
	   		int distance;
	   	 tempx= b.getPosition().getXaxis();
	   	 tempy= b.getPosition().getYaxis();
	   	 for(int i=0; i<30; i++){

	   		 distance=sqrt(pow(tempx-mush[i].getArr()->getXaxis(),2)+pow(tempy - mush[i].getArr()->getYaxis(),2));

	   		 if(distance < 10 ){

               this->score++;
                this->board.drawReal(score);
	   			 DrawSquare( mush[i].getArr()->getXaxis() ,mush[i].getArr()->getYaxis()  ,15,colors[WHITE]);
	   			 mush[i].getArr()->setXaxis(1500);
	   		 }
	   	 }
	   	}
	   	int GAME::getScore() {
	   			return score;
	   		}

	   		void GAME::setScore(int score) {
	   			this->score = score;
	   		}
	   		void GAME::drawForScore(){
	   			stringstream s;
	   			 s<<score;
	   	   string str=s.str();
	   	   DrawString( 130, 800, str, colors[139]);
	   		}
	   	 void GAME::CentipedeDraw(){
	   		 centi.draw();
	   		 centi.drawHead();
	   		if (centi.isTemp()==0)
	   				centi.getM().getPosition().left(5);
	   			if(centi.isTemp()==1)
	   				centi.getM().getPosition().right(5);
	   			if(centi.getM().getX() < 150 ){
	   				centi.setTemp(1);
	   			   centi.getM().getPosition().down(5);
	   			}
	   			  if(centi.getM().getX() >= 1010){
	   				  centi.setTemp(0);
	   			  centi.getM().getPosition().down(5);
	   			  }
	   	  centi.getLazyC()[0].getPosition().setXaxis(centi.getM().getPosition().getXaxis());
	   	  centi.getLazyC()[0].getPosition().setYaxis(centi.getM().getPosition().getYaxis());

	   	  for(int i=9; i>0; i--){

	   		  centi.getLazyC()[i].getPosition().setXaxis(centi.getLazyC()[i-1].getPosition().getXaxis() - 20);
	   		  centi.getLazyC()[i].getPosition().setYaxis(centi.getLazyC()[i-1].getPosition().getYaxis() );

	   	  }
	   	  for(int i=0; i<=9; i++){

	   		  DrawCircle(centi.getLazyC()[i].getPosition().getXaxis() ,centi.getLazyC()[i].getPosition().getYaxis(),10,colors[PURPLE]);

	   	  }
	   	//  glutPostRedisplay();
	   	 }
GAME::~GAME() {
	// TODO Auto-generated destructor stub
}

