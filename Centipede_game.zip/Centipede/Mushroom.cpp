/*
 * Mushroom.cpp
 *
 *  Created on: Apr 30, 2019
 *      Author: naseer
 */

#include "Mushroom.h"
#include<time.h>
#include<stdlib.h>

Mushroom::Mushroom() {
	arr=new Position[30];// TODO Auto-generated constructor stub
	srand(time(0));
	for(int i=0; i<30; i++){

		arr[i].setXaxis(rand()%900);
	    arr[i].setYaxis(rand()%(641)+200);

}
}
void Mushroom::draw(){

	 DrawSquare(  this->getPosition().getXaxis() , this->getPosition().getYaxis()  ,15,colors[GREEN]);
}
void Mushroom::setArr(const Position*& arr) {
//	for(int i=0; i<30; i++){
//	this->arr[i].setXaxis(arr->getXaxis());
//	this->arr[i] .setYaxis(arr->getYaxis());
//	}
	}
 Position*& Mushroom::getArr() {
		return arr;
	}
Mushroom::~Mushroom() {

}

