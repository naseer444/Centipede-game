/*
 * Position.h
 *
 *  Created on: May 3, 2019
 *      Author: naseer
 */

#ifndef POSITION_H_
#define POSITION_H_

class Position {
	int xaxis;
	int yaxis;
public:
	Position();
	Position(int x,int y);
	void up(int y);
	void down(int y);
	void right(int x);
	void left(int x);
	void downforcen(int y);
	virtual ~Position();
    int  getXaxis() const ;
	void setXaxis(int xaxis);
	int getYaxis() const;
	void setYaxis(int yaxis) ;
};

#endif /* POSITION_H_ */
