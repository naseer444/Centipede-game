
/*
 * Player.cpp
 *
 *  Created on: May 1, 2019
 *      Author: naseer
 */

#include "Player.h"
#include "util.h"
#include"Board.h"
#include<iostream>
using namespace std;
Player::Player() {
	// TODO Auto-generated constructor stub

}
Player::Player(int  x,int y){
getPosition().setXaxis(x);
getPosition().setYaxis(y);
}
void Player::increase_x(){
	if(getPosition().getXaxis() > 990 )
			getPosition().setXaxis(989);
	getPosition().right(10);
}
void Player::increase_y(){
	if(getPosition().getYaxis() >200)
			getPosition().setYaxis(199);
 getPosition().up(10);
}
void Player::decrease_x(){
		if(getPosition().getXaxis() < 10)
					getPosition().setXaxis(11);
		 getPosition().left(10);
}
void Player::decrease_y(){
		if(getPosition().getYaxis() < 10)
					getPosition().setYaxis(11);
		 getPosition().down(10);
}
void Player::draw(){
	DrawSquare( getPosition().getXaxis() , getPosition().getYaxis() ,20,colors[RED]);

}
void Player::move(){
		//DrawSquare( startxx , startyy ,40,colors[RED]);
}
Player::~Player() {
	// TODO Auto-generated destructor stub
}


