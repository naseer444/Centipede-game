/*
 * GameObject.cpp
 *
 *  Created on: Apr 30, 2019
 *      Author: naseer
 */

#include "GameObject.h"

GameObject::GameObject(){
	position.setXaxis(0);
	position.setYaxis(0);
}
Position& GameObject::getPosition() {
		return position;
	}

void GameObject::setPosition(const Position& position) {
		this->position = position;
	}

GameObject::~GameObject() {
	// TODO Auto-generated destructor stub
}

