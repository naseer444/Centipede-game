/*
 * Position.cpp
 *
 *  Created on: May 3, 2019
 *      Author: naseer
 */

#include "Position.h"

Position::Position() {
	xaxis=0;
	yaxis=0;

}
Position::Position(int x,int y){
	 xaxis=x;
	 yaxis=y;
}
void Position::up(int y){
yaxis+=y;
}
	void Position::down(int y)
	{
		yaxis-=y;
	}
	void Position::right(int x){
		xaxis+=x;
	}
	void Position::left(int x){
		xaxis-=x;
	}
int Position::getXaxis() const {
		return xaxis;
	}

	void Position::setXaxis(int xaxis) {
		this->xaxis = xaxis;
	}

	int Position::getYaxis() const {
		return yaxis;
	}

	void Position::setYaxis(int yaxis) {
		this->yaxis = yaxis;
	}
	void Position::downforcen(int y){
		this->yaxis-=y;
		this->xaxis+=y;
	}
Position::~Position() {
	// TODO Auto-generated destructor stub
}

