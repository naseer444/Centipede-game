/*
 * ScoreBoard.h
 *
 *  Created on: Apr 30, 2019
 *      Author: naseer
 */

#ifndef SCOREBOARD_H_
#define SCOREBOARD_H_
#include "util.h"
#include<iostream>
#include<sstream>
#include<string>
#include "GameObject.h"
class ScoreBoard :public GameObject{
	int NumberOfLives;
	int score;
public:
	ScoreBoard();
	ScoreBoard(int nl,int s);
	virtual ~ScoreBoard();
    void drawReal(int score);
	int getNumberOfLives() const ;
	void setNumberOfLives(int numberOfLives);

	int getScore() const ;

	void setScore(int score) ;
	void draw();
};

#endif /* SCOREBOARD_H_ */
