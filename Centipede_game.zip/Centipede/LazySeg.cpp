/*
 * LazySeg.cpp
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#include "LazySeg.h"
#include "util.h"
#include "Position.h"

LazySeg::LazySeg() {

}
 void LazySeg::draw(){
			 DrawCircle(getPosition().getXaxis() ,getPosition().getYaxis(),10,colors[PURPLE]);
	 }
 void LazySeg::move(){

 }
 int LazySeg::getX(){
 	return this->getPosition().getXaxis();
 }
    int LazySeg::getY(){
 	   return this->getPosition().getYaxis();
    }
    void LazySeg::setX(int x){
 	   this->getPosition().setXaxis(x);
    }
    void LazySeg::setY(int y){
 	   this->getPosition().setYaxis(y);
    }
LazySeg::~LazySeg() {
	// TODO Auto-generated destructor stub
}

