/*
 * Segment.h
 *
 *  Created on: May 4, 2019
 *      Author: naseer
 */

#ifndef SEGMENT_H_
#define SEGMENT_H_
#include<iostream>
#include"MoveableObject.h"
using namespace std;
class Segment :public MoveableObject{

public:
	Segment();
	virtual ~Segment();
	void move ();
	void draw();

	};

#endif /* SEGMENT_H_ */
