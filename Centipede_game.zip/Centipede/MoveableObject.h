/*
 * MoveableObject.h
 *
 *  Created on: May 1, 2019
 *      Author: naseer
 */

#ifndef MOVEABLEOBJECT_H_
#define MOVEABLEOBJECT_H_
#include<iostream>
#include"GameObject.h"
using namespace std;
class MoveableObject :public GameObject{
public:
	MoveableObject();
	virtual void move()=0;
	void draw();
	virtual ~MoveableObject();
};

#endif /* MOVEABLEOBJECT_H_ */
