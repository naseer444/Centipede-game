/*
 * Player.h
 *
 *  Created on: May 1, 2019
 *      Author: naseer
 */

#ifndef PLAYER_H_
#define PLAYER_H_
#include "util.h"
#include "MoveableObject.h"
#include"Position.h"
//#include"GAME.h"
class Player :public MoveableObject{
public:
	Player();
	Player(int  x,int y);
	void move();
    void draw();
	virtual ~Player();
	void increase_x();
	void increase_y();
	void decrease_x();
	void decrease_y();

};

#endif /* PLAYER_H_ */

