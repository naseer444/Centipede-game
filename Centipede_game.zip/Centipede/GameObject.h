/*
 * GameObject.h
 *
 *  Created on: Apr 30, 2019
 *      Author: naseer
 */

#ifndef GAMEOBJECT_H_
#define GAMEOBJECT_H_
#include<iostream>
#include "Position.h"
using namespace std;
class GameObject {
	Position position;
public:
	GameObject();
	virtual void draw()=0;
	virtual ~GameObject();
	Position& getPosition();
	void setPosition(const Position& position) ;
};

#endif /* GAMEOBJECT_H_ */
